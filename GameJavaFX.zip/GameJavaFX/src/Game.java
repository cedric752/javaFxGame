
import java.io.File;
import java.io.InputStream;
import java.util.Random;
import javafx.animation.AnimationTimer;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.media.AudioClip;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;
import sun.audio.AudioStream;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 31680
 */
public class Game
{
    private AnchorPane gamePane;
    private Scene gameScene;
    private Stage gameStage;
    
    private static final int GAME_WIDTH = 600;
    private static final int GAME_HEIGHT = 800;
    
    private Stage menuStage;
    private ImageView player;
    
    private boolean isLeftKeyPressed;
    private boolean isRightPressed;
    private int angle;
    private AnimationTimer gameTimer;
    
    private GridPane gridPane1;
    private GridPane gridPane2;
    private final String BACKGROUND_IMAGE = "/images/darkPurple.png";
    
    private final static String VIRUS_ENEMY = "/images/ghost.png";
    private final static String VIRUS_ENEMY_RED = "/images/spinner.png";
    
    
    private ImageView[] enemies;
    private ImageView[] redEnemies;
    Random randomPositionGenerator;
    
    private ImageView star;
    private SmallLabel pointsLabel;
    private ImageView[] playerLifes;
    private int playerLife;
    private int points;
    private final static String GOLD_STAR = "/images/star_gold.png";
    
    private final static int STAR_RADIUS = 12;
    private final static int PLAYER_RADIUS = 27;
    private final static int ENEMY_RADIUS = 20; 
    
    public Game()
    {
        initializeStage();
        createKeyListeners();
        randomPositionGenerator = new Random();
        
        
    }
    
    private void initializeStage()
    {
        gamePane = new AnchorPane();
        gameScene = new Scene(gamePane, GAME_WIDTH, GAME_HEIGHT);
        gameStage = new Stage();
        gameStage.setScene(gameScene);
    }
    
    private void createKeyListeners()
    {
        gameScene.setOnKeyPressed(new EventHandler<KeyEvent>(){
        
        @Override
        public void handle(KeyEvent event)
        {
            if(event.getCode() == KeyCode.A)
            {
                isLeftKeyPressed = true;
            }
            else if(event.getCode() == KeyCode.D)
            {
                isRightPressed = true;
            }
        }
    });
        
        gameScene.setOnKeyReleased(new EventHandler<KeyEvent>(){
        
            @Override
            public void handle(KeyEvent event)
            {
              if(event.getCode() == KeyCode.A)
              {
                isLeftKeyPressed = false;
              }
              else if(event.getCode() == KeyCode.D)
              {
                isRightPressed = false;
              }
            }
       });
    }
    
    
    public void createNewGame(Stage menuStage, Player choosenPlayer)
    {
        this.menuStage = menuStage;
        this.menuStage.hide();
        createBackground();
        createPlayer(choosenPlayer);
        createElements(choosenPlayer);
        gameStage.show();
        createGameLoop();
        
    }
    
    private void createElements(Player choosenPlayer)
    {
        playerLife = 2;
        star = new ImageView(GOLD_STAR);
        setPosition(star);
        gamePane.getChildren().add(star);
        pointsLabel = new SmallLabel("POINTS : 00");
        pointsLabel.setLayoutX(460);
        pointsLabel.setLayoutY(20);
        gamePane.getChildren().add(pointsLabel);
        playerLifes = new ImageView[3];
        
        for(int i = 0; i < playerLifes.length; i++)
        {
            playerLifes[i] = new ImageView(choosenPlayer.getUrlLife());
            playerLifes[i].setLayoutX(455 +(i * 50));
            playerLifes[i].setLayoutY(80);
            gamePane.getChildren().add(playerLifes[i]);
        }
        
        
        enemies = new ImageView[3];
        for(int i = 0; i < enemies.length; i++)
        {
            
            enemies[i] = new ImageView(VIRUS_ENEMY);
            enemies[i].prefHeight(5);
            enemies[i].prefWidth(5);
            setPosition(enemies[i]);
            gamePane.getChildren().add(enemies[i]);
        }
        
        redEnemies = new ImageView[3];
        for(int i = 0; i < enemies.length; i++)
        {
            
            redEnemies[i] = new ImageView(VIRUS_ENEMY_RED);
            redEnemies[i].prefHeight(5);
            redEnemies[i].prefWidth(5);
            setPosition(redEnemies[i]);
            gamePane.getChildren().add(redEnemies[i]);
        }
    }
    
    private void moveElements()
    {
        star.setLayoutY(star.getLayoutY() + 5);
        
        for(int i = 0; i < enemies.length; i++)
        {
            enemies[i].setLayoutY(enemies[i].getLayoutY() + 7);
            enemies[i].setRotate(enemies[i].getRotate() + 4);
        }
        
        for(int i = 0; i < redEnemies.length; i++)
        {
            redEnemies[i].setLayoutY(redEnemies[i].getLayoutY() + 7);
            redEnemies[i].setRotate(redEnemies[i].getRotate() + 4);
        }
    }
    
    private void checkEnemyPosition()
    {
        if(star.getLayoutY() > 1200)
        {
            setPosition(star);
        }
        
        for(int i = 0; i < enemies.length; i++)
        {
            if(enemies[i].getLayoutY() > 900)
            {
                setPosition(enemies[i]);
            }
        }
        for(int i = 0; i < redEnemies.length; i++)
        {
            if(redEnemies[i].getLayoutY() > 900)
            {
                setPosition(redEnemies[i]);
            }
        }
    }
    
    private void setPosition(ImageView image)
    {
        image.setLayoutX(randomPositionGenerator.nextInt(370));
        image.setLayoutY(-(randomPositionGenerator.nextInt(3200)+ 600));
    }
    
    private void createPlayer(Player choosenPlayer)
    {
        player = new ImageView(choosenPlayer.getUrl());
        player.setLayoutX(GAME_WIDTH / 2);
        player.setLayoutY(GAME_HEIGHT - 115);
        gamePane.getChildren().add(player);
    }
    
    private void createGameLoop()
    {
        gameTimer = new AnimationTimer()
        {
            @Override
            public void handle(long now)
            {
                moveBackground();
                moveElements();
                checkEnemyPosition();
                checkIfCollide();
                movePlayer();  
            }
        };
        gameTimer.start();
    }
    
    private void movePlayer()
    {
        if(isLeftKeyPressed && !isRightPressed)
        {
            if(angle > -30)
            {
                angle -= 5;
            }
            player.setRotate(angle);
            
            if(player.getLayoutX() > -20)
            {
                player.setLayoutX(player.getLayoutX() - 3);
            }
        }
        if(isRightPressed && !isLeftKeyPressed)
        {
            if(angle < 30)
            {
                angle += 5;
            }
            player.setRotate(angle);
            
            if(player.getLayoutX() < 522)
            {
                player.setLayoutX(player.getLayoutX() + 3);
            }
        }
        if(!isLeftKeyPressed && !isRightPressed)
        {
            if(angle <0)
            {
                angle += 5;
            } else if(angle > 0) 
            {
                angle -=5;
            }
            player.setRotate(angle);
        }
        if(isLeftKeyPressed && isRightPressed)
        {
            if(angle <0)
            {
                angle += 5;
            } else if(angle > 0) 
            {
                angle -=5;
            }
            player.setRotate(angle);
        }
        
    }
    private void createBackground()
        {
           gridPane1 = new GridPane();
           gridPane2 = new GridPane();
           
           for(int i = 0; i < 12; i++)
           {
               ImageView backgroundImage1 = new ImageView(BACKGROUND_IMAGE);
               ImageView backgroundImage2 = new ImageView(BACKGROUND_IMAGE);
               GridPane.setConstraints(backgroundImage1, i%3, i / 3);
               GridPane.setConstraints(backgroundImage2, i%3, i / 3);
               gridPane1.getChildren().add(backgroundImage1);
               gridPane2.getChildren().add(backgroundImage2);
               
           }
           
           gridPane2.setLayoutY(-1024);
           gamePane.getChildren().addAll(gridPane1, gridPane2);
           
        }
    
        private void moveBackground()
        {
            gridPane1.setLayoutY(gridPane1.getLayoutY() + 0.5);
            gridPane2.setLayoutY(gridPane2.getLayoutY() + 0.5);
            
            if(gridPane1.getLayoutY() >= 1024)
            {
                gridPane1.setLayoutY(-1024);
            }
              if(gridPane2.getLayoutY() >= 1024)
            {
                gridPane2.setLayoutY(-1024);
            }
        }
        
        private void checkIfCollide()
        {
            if(PLAYER_RADIUS + STAR_RADIUS > calculateDistance(player.getLayoutX() + 49, star.getLayoutX() + 15, player.getLayoutY() + 37, star.getLayoutY() + 15))
                    {
                        setPosition(star);
                        playSound();
                        points++;
                        String textToSet = "POINTS :";
                        if(points < 10)
                        {
                            textToSet = textToSet + "0";
                        }
                        pointsLabel.setText(textToSet + points);
                    }
            for( int i = 0; i < enemies.length; i++)
            {
                if(ENEMY_RADIUS + PLAYER_RADIUS > calculateDistance(player.getLayoutX() + 49,enemies[i].getLayoutX() + 20 , player.getLayoutY() + 37 , enemies[i].getLayoutY() + 20))
                {
                    removeLife();
                    playLifeRemoveSound();
                    setPosition(enemies[i]);
                }
            }
            
            for( int i = 0; i < redEnemies.length; i++)
            {
                if(ENEMY_RADIUS + PLAYER_RADIUS > calculateDistance(player.getLayoutX() + 49,redEnemies[i].getLayoutX() + 20 , player.getLayoutY() + 37 , redEnemies[i].getLayoutY() + 20))
                {
                    removeLife();
                    setPosition(redEnemies[i]);
                }
            }
        }
        
        private void removeLife()
        {
            gamePane.getChildren().remove(playerLifes[playerLife]);
            playerLife--;
            if(playerLife < 0)
            {
                gameStage.close();
                gameTimer.stop();
                menuStage.show();
            }
        }
        
       private double calculateDistance(double x1, double x2, double y1, double y2) 
       {
           return Math.sqrt(Math.pow(x1 - x2, 2) + Math.pow(y1 - y2, 2));
       }
       
       private void playSound()
       {
           AudioClip starsound  = new AudioClip(this.getClass().getResource("images/Pling.wav").toString());
           starsound.play(); 
       }
       
       
       private void playBackgroundMusic()
       {
            
       }
       
       private void playLifeRemoveSound()
       {
           AudioClip removelife  = new AudioClip(this.getClass().getResource("images/removelifeSound.wav").toString());
           removelife.play();
       }
}   

