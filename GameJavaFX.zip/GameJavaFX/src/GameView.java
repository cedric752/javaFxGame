

import java.util.ArrayList;
import java.util.List;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Slider;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.HBox;

/**
 * "Aan de slag met Java en JavaFX" viewklasse
 * @author 31680
 */
public class GameView 
{
    private static final int WIDTH = 1024;
    private static final int HEIGHT = 768;
    private AnchorPane mainPane;
    private Scene mainScene;
    private Stage mainStage;
    
    private final static int MENU_BUTTONS_START_X = 100;
    private final static int MENU_BUTTONS_START_Y = 150;
    
    
    private VirusGameSubScene playerChooserSubScene;
    private VirusGameSubScene optionsSubScene;
    private VirusGameSubScene sceneToHide;
    
    List<VirusButton> menuButtons;
    
    List<PlayerPicker> playerList;
    
    private Player choosenPlayer;
    

    public GameView() 
    {
       menuButtons = new ArrayList<>();
       mainPane = new AnchorPane();
       mainScene = new Scene(mainPane, WIDTH, HEIGHT);
       mainStage = new Stage();
       mainStage.setScene( mainScene );
       createSubScenes();
       maakButtons();
       createBackground();
       createLogo();
       
       
       
       
    }
    
    private void showSubScene(VirusGameSubScene subScene)
    {
        if(sceneToHide != null)
        {
            sceneToHide.moveSubScene();
        }
        
        subScene.moveSubScene();
        sceneToHide = subScene;
    }
    
    private void createSubScenes()
    {
        
        createOptionsSubScene();
        createPlayerChooserSubScene();
    }
    
    private void createPlayerChooserSubScene()
    {
        playerChooserSubScene = new VirusGameSubScene();
        mainPane.getChildren().add(playerChooserSubScene);
        
        VirusLabel choosePlayerLabel = new VirusLabel("KIES JE SPELER");
        choosePlayerLabel.setLayoutX(110);
        choosePlayerLabel.setLayoutY(25);
        playerChooserSubScene.getPane().getChildren().add(choosePlayerLabel);
        playerChooserSubScene.getPane().getChildren().add(createButtonToStart());
        playerChooserSubScene.getPane().getChildren().add(createPlayerToChoose());
        
        
    }
    
    private void createOptionsSubScene()
    {
        optionsSubScene = new VirusGameSubScene();
        mainPane.getChildren().add(optionsSubScene);
        
        VirusLabel optionsLabel = new VirusLabel("OPTIES");
        optionsLabel.setLayoutX(100);
        optionsLabel.setLayoutY(20);
        SmallLabel geluidLabel = new SmallLabel("Geluid");
        geluidLabel.setLayoutX(50);
        geluidLabel.setLayoutY(100);
        Slider geluidSlider = new Slider();
        geluidSlider.setLayoutX(50);
        geluidSlider.setLayoutY(120);
        geluidSlider.setPrefSize(250, 140);
        geluidSlider.setShowTickLabels(true);
        geluidSlider.setShowTickMarks(true);
        
        SmallLabel muziekLabel = new SmallLabel("Muziek");
        muziekLabel.setLayoutX(50);
        muziekLabel.setLayoutY(210);
        Slider muziekSlider = new Slider();
        muziekSlider.setLayoutX(50);
        muziekSlider.setLayoutY(230);
        muziekSlider.setPrefSize(250, 140);
        muziekSlider.setShowTickLabels(true);
        muziekSlider.setShowTickMarks(true);
        
        optionsSubScene.getPane().getChildren().add(muziekLabel);
        optionsSubScene.getPane().getChildren().add(muziekSlider);
        optionsSubScene.getPane().getChildren().add(geluidSlider);
        optionsSubScene.getPane().getChildren().add(geluidLabel);
        optionsSubScene.getPane().getChildren().add(optionsLabel);
    }
    
    private HBox createPlayerToChoose()
    {
        HBox box = new HBox();
        box.setSpacing(20);
        playerList = new ArrayList<>();
        for(Player player : Player.values())
        {
            PlayerPicker playerToPick = new PlayerPicker(player);
            playerList.add(playerToPick);
            box.getChildren().add(playerToPick);
            playerToPick.setOnMouseClicked(new EventHandler<MouseEvent>()
            {
                @Override
                public void handle(MouseEvent event)
                {
                    for(PlayerPicker player : playerList)
                    {
                        player.setIsCircleChecken(false);
                    }
                    playerToPick.setIsCircleChecken(true);
                    choosenPlayer = playerToPick.getPlayer();
                }
            });
            
        }
        box.setLayoutX(300 -(118*2));
        box.setLayoutY(100);
        return box;
    }
    
    public Stage getMainStage()
    {
        return mainStage;
    }
    
    private void addMenuButton(VirusButton button)
    {
        button.setLayoutX(MENU_BUTTONS_START_X);
        button.setLayoutY(MENU_BUTTONS_START_Y + menuButtons.size() * 100);
        menuButtons.add(button);
        mainPane.getChildren().add(button);
        
    }
    
    private void maakButtons() 
    {  
        createStartButton();
        createOptionsButton();
        createExitButton();
        
    }
    
    private void createStartButton()
    {
        VirusButton start = new VirusButton("PLAY");
        addMenuButton(start);
        
        start.setOnAction(new EventHandler<ActionEvent>()
        {
            @Override
            public void handle(ActionEvent event){
                showSubScene(playerChooserSubScene);
            }
        });
        
        
    }
    private VirusButton createButtonToStart()
    {
        VirusButton startButton = new VirusButton("START");
        startButton.setLayoutX(350);
        startButton.setLayoutY(300);
        
         startButton.setOnAction(new EventHandler<ActionEvent>(){
        
            @Override
            public void handle(ActionEvent event)
            {
                if(choosenPlayer != null)
                {
                    Game game = new Game();
                    game.createNewGame(mainStage, choosenPlayer);
                }
            }
        });
        
        return startButton;
    }
    
    private void createOptionsButton()
    {
        VirusButton options = new VirusButton("OPTIONS");
        addMenuButton(options);
        
        options.setOnAction(new EventHandler<ActionEvent>()
        {
            @Override
            public void handle(ActionEvent event)
            {
                showSubScene(optionsSubScene);
            }
        });
    }
    
    
    private void createExitButton()
    {
        VirusButton exit = new VirusButton("EXIT");
        addMenuButton(exit);
        
        exit.setOnAction(new EventHandler<ActionEvent>()
        {
            @Override 
            public void handle(ActionEvent event)
            {
                mainStage.close();
            }
        });
    }
    
    private void createBackground()
    {
        Image backgroundImage = new Image("/backgroundres/grass.png", 254, 256, false, true);
        BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.REPEAT, BackgroundRepeat.REPEAT, BackgroundPosition.DEFAULT, null);
        mainPane.setBackground(new Background(background));
    }
    private void createLogo()
    {
        ImageView logo = new ImageView("/images/virus_logo.png");
        logo.setLayoutX(400);
        logo.setLayoutY(50);
        
        logo.setOnMouseEntered(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                logo.setEffect(new DropShadow());
            }
        });
        logo.setOnMouseExited(new EventHandler<MouseEvent>(){
            @Override
            public void handle(MouseEvent event)
            {
                logo.setEffect(null);
            }
        });
        mainPane.getChildren().add(logo);
    }
     
}

    /**
    *   Dit is een voorbeeldmethode die eigenlijk in een Controller hoort
    */
     
    

