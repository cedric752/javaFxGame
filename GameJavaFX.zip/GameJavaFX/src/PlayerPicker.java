
import javafx.geometry.Pos;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 31680
 */

public class PlayerPicker extends VBox
{
    private ImageView circleImage;
    private ImageView playerImage;
    
    private String circleNotChecked = "/images/grey_circle.png";
    private String circleChecked = "/images/green_circle.png";
    
    private Player player;
    
    private boolean isCircleChecked;
    
    public PlayerPicker(Player player)
    {
        circleImage = new ImageView(circleNotChecked);
        playerImage = new ImageView(player.getUrl());
        this.player = player;
        isCircleChecked = false;
        this.setAlignment(Pos.CENTER);
        this.setSpacing(20);
        this.getChildren().add(circleImage);
        this.getChildren().add(playerImage);
    }
    
    public Player getPlayer()
    {
        return player;
    }
    
    public boolean getIsCircleChecked()
    {
        return isCircleChecked;
    }
    public void setIsCircleChecken(boolean isCircleChecked)
    {
        this.isCircleChecked = isCircleChecked;
        String imageToSet = this.isCircleChecked ? circleChecked : circleNotChecked;
        circleImage.setImage(new Image(imageToSet));
    }
    
    
}


