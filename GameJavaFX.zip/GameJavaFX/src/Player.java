/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 31680
 */

public enum Player
{
    Player1("/images/adventurer_action2.png", "/images/green_circle.png"),
    Player2("/images/player_duck.png", "/images/green_circle.png" ),
    Player3("/images/soldier_action1.png", "/images/green_circle.png"),
    Player4("/images/zombie_jump.png", "/images/green_circle.png"),
    Player5("/images/female_idle.png", "/images/green_circle.png");
            
    private String urlplayer;
    private String urlLife;
    
    private Player(String urlplayer, String urlLife)
    {
        this.urlplayer = urlplayer;
        this.urlLife = urlLife;
    }
    
    public String getUrl()
    {
        return this.urlplayer;
    }
    
    public String getUrlLife()
    {
        return urlLife;
    }
}
